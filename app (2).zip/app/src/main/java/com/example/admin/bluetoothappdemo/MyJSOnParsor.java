package com.example.admin.bluetoothappdemo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MyJSOnParsor {
	public List<List<HashMap<String, String>>> parse(JSONArray jsRoutes) {

		List<List<HashMap<String, String>>> routes = new ArrayList<List<HashMap<String, String>>>();
		JSONArray jLegs = null;
		JSONArray jSteps = null;
		JSONObject jDistance = null;
		JSONObject jDuration = null;

		try {

			/** Traversing all routes */
			for (int i = 0; i < jsRoutes.length(); i++) {
				JSONObject jsObj = jsRoutes.getJSONObject(i);
				List<HashMap<String, String>> path=new ArrayList<HashMap<String,String>>();
				

			}

			// routes.add(path);
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (Exception e) {
		}

		return routes;
	}
}
