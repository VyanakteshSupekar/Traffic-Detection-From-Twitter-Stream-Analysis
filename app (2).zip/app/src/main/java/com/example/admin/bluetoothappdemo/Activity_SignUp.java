package com.example.admin.bluetoothappdemo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import config.Validation;
import database.SQLiteAdapter;


public class Activity_SignUp extends AppCompatActivity {

    //edittext declaration
    EditText edtEmailid,edtPassword,edtName,editTextUsername,edtMobile1;
    String strPassword,strName,strUsername,strMobile1;
    Button buttonRegister;

    private ProgressDialog pDialog;


    SQLiteAdapter dbhelper;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);//set layout


        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

     //database constructor call
        dbhelper=new SQLiteAdapter(getApplicationContext());
        //initilisation of edittext
        edtName=(EditText)findViewById(R.id.editTextName);
        edtName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {




            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String name=s.toString();

                if(Validation.isNAme(name))
                {

                }else{
                    edtName.setError("Enter Valid Name");
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        editTextUsername=(EditText)findViewById(R.id.editTextUsername);
        editTextUsername.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {




            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String name=s.toString();

                if(Validation.isValidEmail(name))
                {

                }else{
                    editTextUsername.setError("Enter Valid Email/username");
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        edtMobile1=(EditText)findViewById(R.id.editTextMobile1);
        edtMobile1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {




            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String name=s.toString();

                if(Validation.isMobNo(name))
                {

                }else{
                    edtMobile1.setError("Mobile number must be 10 digit");
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
         edtPassword=(EditText)findViewById(R.id.editTextPassword);
        edtPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {




            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String name=s.toString();

                if(name.length()>5)
                {
                    if(Validation.isalphanumeric(name))
                    {

                    }else{
                        edtPassword.setError("Password number must be 6 digit and alphanumric");
                    }

                }else{
                    edtPassword.setError("Password number must be 6 digit and alphanumric");
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        buttonRegister=(Button)findViewById(R.id.buttonRegister);
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get data from editttext
                strPassword = edtPassword.getText().toString();
                strName = edtName.getText().toString();
                strUsername = editTextUsername.getText().toString();
                strMobile1 = edtMobile1.getText().toString();




                    if (!strName.equals("")) {

                        if(Validation.isNAme(strName))
                        {


                        if (!strUsername.equals("")) {
                            if(Validation.isValidEmail(strUsername))
                            {


                            if (!strPassword.equals("")) {

                                if(strPassword.length()>5)
                                {
                                    if(Validation.isalphanumeric(strPassword))
                                    {


                                if (!strMobile1.equals("")) {

                                    if (Validation.isMobNo(strMobile1)) {

                                       //store in sqllite database

                                        Toast.makeText(getApplicationContext(), "Register Successfully", Toast.LENGTH_SHORT).show();

                                        dbhelper.openToWrite();
                                        int toatluser= dbhelper.Get_Total_User();
                                        dbhelper.close();

                                        dbhelper.openToWrite();
                                        dbhelper.deleteUser();
                                        dbhelper.insertUser(strName, strUsername, strPassword, strMobile1);
                                        dbhelper.close();



                                        finish();
                                        Intent i=new Intent(getApplicationContext(),Activity_Login.class);
                                        startActivity(i);

                                    } else {
                                        edtMobile1.setText("");
                                        edtMobile1.setHint("Please Enter valid Mobile");
                                        edtMobile1.requestFocus();
                                    }


                                } else {
                                    edtMobile1.setText("");
                                    edtMobile1.setHint("Please Enter Mobile");
                                    edtMobile1.requestFocus();
                                }

                                    }else{
                                        edtPassword.setError("Password number must be 6 digit and alphanumric");
                                    }

                                }else{
                                    edtPassword.setError("Password number must be 6 digit and alphanumric");
                                }

                            } else {
                                edtPassword.setText("");
                                edtPassword.setHint("Please Enter Password");
                                edtPassword.requestFocus();
                            }

                            }else{
                                editTextUsername.setError("Enter Valid Email/username");
                            }

                        } else {
                            editTextUsername.setText("");
                            editTextUsername.setHint("Please Enter UserName");
                            editTextUsername.requestFocus();
                        }
                        }else{
                            edtName.setError("Enter Valid Name");
                        }

                    } else {
                        edtName.setText("");
                        edtName.setHint("Please Enter Name");
                            edtName.requestFocus();
                    }



        }
        });



    }




}
