package com.example.admin.bluetoothappdemo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import database.SQLiteAdapter;
import database.User;


public class Activity_Login extends AppCompatActivity {

    //edittext declaration
    EditText edtUserName,edtPassword;
    String strUserName,strPassword;
    //Button declaration
    Button btnLogin;
    TextView textSignup;

    private ProgressDialog pDialog;

    SQLiteAdapter dbhelper;
    Toolbar toolbar;
    String flag="0";
    public static String userLogin="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);//set layout
        dbhelper=new SQLiteAdapter(getApplicationContext());

        dbhelper.openToRead();
        int id=dbhelper.Get_Total_User();

        Log.d("#########","count :- "+id);
        if(id>0)
        {

            finish();
            //start MAin activity
            Intent i=new Intent(getApplicationContext(),MenuActivity.class);
            startActivity(i);
        }
        dbhelper.close();

        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);

        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //call sqllite database constructor

        //initilisation of edittext
        edtUserName=(EditText)findViewById(R.id.editTextUserName);
        edtPassword=(EditText)findViewById(R.id.editTextPassword);
        btnLogin=(Button)findViewById(R.id.buttonLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //get data from editttext
                strUserName=edtUserName.getText().toString();
                strPassword=edtPassword.getText().toString();

                if(!strUserName.equals(""))
                {

                    if(!strPassword.equals("")) {






                         //open database to read data from table
                      dbhelper.openToRead();
                       ArrayList<User> userlist= dbhelper.retrieveAllUser();
                        for(int i=0;i<userlist.size();i++)
                        {
                            String username=userlist.get(i).getUsername();
                            String password=userlist.get(i).getPassword();
                            String name=userlist.get(i).getName();
                            //check username and password
                            if(strUserName.equals(username)&&strPassword.equals(password))
                            {
                                flag="1";
                                userLogin=name;
                                break;

                            }
                        }
                        dbhelper.close();


                      if(flag.equals("1")){


                          //Show message
                        Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_SHORT).show();

                          finish();
                          //start MAin activity
                       Intent i=new Intent(getApplicationContext(),MenuActivity.class);
                        startActivity(i);




                    }else {

                        Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_SHORT).show();

                        edtPassword.setText("");
                        edtPassword.setHint("Please Enter Password");
                        edtUserName.setText("");
                        edtUserName.setHint("Please Enter UserName");


                    }


                    }else{
                        edtPassword.setText("");
                        edtPassword.setHint("Please Enter Password");
                        edtPassword.requestFocus();
                    }

                }else{
                    edtUserName.setText("");
                    edtUserName.setHint("Please Enter UserName");
                    edtUserName.requestFocus();
                }


            }
        });


        textSignup=(TextView)findViewById(R.id.textViewSignup);
        textSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //start signup Activity
                Intent i=new Intent(getApplicationContext(),Activity_SignUp.class);
                startActivity(i);

               // call();
            }
        });
    }


}
