package com.example.admin.bluetoothappdemo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import config.CustomRequest;
import config.ProjectConfig;

public class Show_LiveTracking extends FragmentActivity  implements OnMapReadyCallback{
	private GoogleMap googleMap1;

	int p;  //Selected Route Number
	private ProgressDialog pDialog;
	TextView tvDistanceDuration;
	String str_destination,str_source;
	//String a;
	String data;

	JSONArray jsonArray;

	JSONArray jarray;
	//String rout_array;
	Button changePath;
	JSONObject jObject;
	int routeCount;     //number of routes
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);


		setContentView(R.layout.screen_popup);//set layout

		changePath=(Button) findViewById(R.id.changePath);
		p=0;


		changePath.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if(p<routeCount-1){
					p++;
				}
				else{
					p=0;
				}

				jarray=new JSONArray();
				ParserTask parserTask = new ParserTask();

				// Invokes the thread for parsing the JSON data
				parserTask.execute(data);
			}

		});

		tvDistanceDuration=(TextView)findViewById(R.id.textView);
		//keep screen on
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		//get value from other activity
		Intent i1 = getIntent();
		str_source = i1.getExtras().getString("source");
		str_destination = i1.getExtras().getString("destination");


/*

			if (googleMap == null) {
				googleMap = ((SupportMapFragment) getSupportFragmentManager()
						.findFragmentById(R.id.map)).getMap();
			}
*/


		SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
				.findFragmentById(R.id.map);
		mapFragment.getMapAsync(this);
		
	}


	/** A method to download json data from url */
	private String downloadUrl(String strUrl) throws IOException {
		String data = "";
		InputStream iStream = null;
		HttpURLConnection urlConnection = null;
		try {
			URL url = new URL(strUrl);

			// Creating an http connection to communicate with url
			urlConnection = (HttpURLConnection) url.openConnection();

			// Connecting to url
			urlConnection.connect();

			// Reading data from url
			iStream = urlConnection.getInputStream();

			BufferedReader br = new BufferedReader(new InputStreamReader(
					iStream));

			StringBuffer sb = new StringBuffer();

			String line = "";
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

			data = sb.toString();

			br.close();

		} catch (Exception e) {
			//Log.d("Exception while downloading url", e.toString());
		} finally {
			iStream.close();
			urlConnection.disconnect();
		}
		return data;
	}

	@Override
	public void onMapReady(GoogleMap googleMap) {

		googleMap1=googleMap;
		String url = getDirectionsUrl();
		url=url.replace(" ","%20");
		new DownloadTask().execute(url);


	}

	// Fetches data from url passed
	private class DownloadTask extends AsyncTask<String, Void, String> {

		// Downloading data in non-ui thread
		@Override
		protected String doInBackground(String... url) {

			// For storing data from web service
			String data = "";

			try {
				// Fetching the data from web service
				data = downloadUrl(url[0]);
			} catch (Exception e) {
				Log.d("Background Task", e.toString());
			}
			return data;
		}

		// Executes in UI thread, after the execution of
		// doInBackground()
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			data=result;
			ParserTask parserTask = new ParserTask();

			// Invokes the thread for parsing the JSON data
			parserTask.execute(result);

		}
	}

	/** A class to parse the Google Places in JSON format */
	private class ParserTask extends
			AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {

		// Parsing the data in non-ui thread
		@Override
		protected List<List<HashMap<String, String>>> doInBackground(
				String... jsonData) {


			List<List<HashMap<String, String>>> routes = null;

			try {
				jObject = new JSONObject(jsonData[0]);
				DirectionsJSONParser parser = new DirectionsJSONParser();

				// Starts parsing data
				routes = parser.parse(jObject);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return routes;
		}

		// Executes in UI thread, after the parsing process
		@Override
		protected void onPostExecute(List<List<HashMap<String, String>>> result) {
			ArrayList<LatLng> points = null;

			routeCount=result.size();

			PolylineOptions lineOptions = null;
			MarkerOptions markerOptions = new MarkerOptions();
			String distance = "";
			String duration = "";

			Log.i("Result", "" + result);

			if (result.size() < 1) {
				Toast.makeText(getBaseContext(), "No Points",
						Toast.LENGTH_SHORT).show();
				return;
			}

			// Traversing through all the routes
			//	for (int i = 0; i < result.size(); i++) {
			points = new ArrayList<LatLng>();
			lineOptions = new PolylineOptions();
			jsonArray = new JSONArray();
			// Fetching i-th route
			List<HashMap<String, String>> path = result.get(p);
			points.clear();

			// Fetching all the points in i-th route
			for (int j = 0; j < path.size(); j++) {
				HashMap<String, String> point = path.get(j);
				JSONObject element =new JSONObject();
				if (j == 0) { // Get distance from the list
					distance = (String) point.get("distance");
					continue;
				} else if (j == 1) { // Get duration from the list
					duration = (String) point.get("duration");
					continue;
				}




				double lat = Double.parseDouble(point.get("lat"));
				double lng = Double.parseDouble(point.get("lng"));
				LatLng position = new LatLng(lat, lng);



				try {
					element.put("lat", lat + "");

					element.put("lon", lng + "");

				} catch (JSONException e) {
					e.printStackTrace();
				}

				jsonArray.put(element);





					CameraPosition cameraPosition = new CameraPosition.Builder()
							.target(new LatLng(lat, lng)).zoom(13).build();

					googleMap1.animateCamera(CameraUpdateFactory
							.newCameraPosition(cameraPosition));




				points.add(position);
			}
			// Adding all the points in the route to LineOptions
			lineOptions.addAll(points);
			lineOptions.width(4);
			lineOptions.color(Color.BLUE);

			// Changing the color polyline according to the mode

			//}

			if (result.size() < 1) {
				Toast.makeText(getBaseContext(), "No Points",
						Toast.LENGTH_SHORT).show();
				return;
			}
			tvDistanceDuration.setText("Distance:" + distance + ", Duration:"
					+ duration);

			try {
				googleMap1.clear();

				makesource_destination();
				googleMap1.addPolyline(lineOptions);
			}catch (Exception e)
			{

			}
		}
	}


	private String getDirectionsUrl() {

		// Origin of route
		String str_origin = "origin=" +str_source;
		//	String str_origin = "Nashik";
		// Destination of route
		String str_dest = "destination=" +str_destination;
		//String str_dest = "Pune";
		// Sensor enabled
		String sensor = "sensor=false";

		// Travelling Mode
		String mode = "mode=driving";
		String alternate="alternatives=true";



		String parameters = str_origin + "&" + str_dest + "&" + sensor + "&"
				+ mode + "&"+alternate;

		// Output format
		String output = "json";

		// Building the url to the web service
		String url = "https://maps.googleapis.com/maps/api/directions/"
				+ output + "?" + parameters;

		return url;
	}


	public void setMarker(){

		//place marker on map
		try {

			System.out.println("## jarray.length():"+jarray.length());
			for(int i=0;i<jarray.length();i++) {

				JSONObject jobj =jarray.getJSONObject(i);

				double lat = jobj.getDouble("latitude");
				double lng = jobj.getDouble("longitude");
				String tweet=jobj.getString("tweet");

				System.out.println("## lat:"+lat);


				MarkerOptions marker = new MarkerOptions().position(
						new LatLng(lat, lng)).title("Reason:"+tweet);
				marker.icon(BitmapDescriptorFactory
						.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
				googleMap1.addMarker(marker);
			}

			if (googleMap1 == null) {
				Toast.makeText(getApplicationContext(),
						"Sorry! unable to create maps", Toast.LENGTH_SHORT)
						.show();
			}

		} catch (Exception e) {

		}

	}


	private void makesource_destination() {

		pDialog = new ProgressDialog(Show_LiveTracking.this);
		pDialog.setMessage("Please wait...");
		pDialog.setCancelable(false);
		pDialog.show();

		JSONObject data,sendData;
		sendData=new JSONObject();
		try
		{
			sendData.put("result", "success");
			sendData.put("data", jsonArray);


		}
		catch(Exception e)
		{

		}
		Map<String, String> params=new HashMap<>();
		params.put("JsonData",sendData.toString() );


		System.out.println("##  params:" + params.toString());


		RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
		CustomRequest jsObjRequest = new CustomRequest(Request.Method.POST, ProjectConfig.MAIN_URL, params, this.createRequestSuccessListenersource_destination(), this.createRequestErrorListenersource_destination());
		jsObjRequest.setRetryPolicy(new DefaultRetryPolicy(
				11000,
				DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
				DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
		requestQueue.add(jsObjRequest);
		//requestQueue.add(jsObjRequest);
	}

	private Response.ErrorListener createRequestErrorListenersource_destination() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.i("##", "##" + error.toString());

				if (pDialog.isShowing())
					pDialog.dismiss();
			}
		};
	}

	private Response.Listener<JSONObject> createRequestSuccessListenersource_destination() {
		return new Response.Listener<JSONObject>() {
			@Override
			public void onResponse(JSONObject response) {


				if (pDialog.isShowing())
					pDialog.dismiss();


				System.out.println("##  response:"+response.toString());
				// ##  response:{"result":"fail","data":[]}
				try {
					String result=response.getString("result");
					if(result.equals("fail"))
					{
						Toast.makeText(getApplicationContext(),"Failed to fetch results..",Toast.LENGTH_SHORT).show();
					}
					else {
						Toast.makeText(getApplicationContext(),"result is :- "+result,Toast.LENGTH_SHORT).show();
						jarray = response.getJSONArray("data");
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}

				setMarker();

			}
		};

	};



}
