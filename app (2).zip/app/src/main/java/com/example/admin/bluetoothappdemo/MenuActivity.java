package com.example.admin.bluetoothappdemo;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import config.ProjectConfig;

public class MenuActivity extends AppCompatActivity {
    String  MODE_DRIVING = "";
    String source="katraj",destination="swargate";
    JSONArray jsonArray;

    Button buttonfind;
    public static String LAT="0.0",LONG="0.0";
    Button btnfind,buttonlogout;

    public static String mysocketserviceflag="0";

    private ProgressDialog pDialog;


    Toolbar toolbar;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_menu);

        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);



        btnfind=(Button)findViewById(R.id.buttonfind);
        btnfind.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                alert();


            }
        });

        buttonlogout=(Button)findViewById(R.id.buttonlogout);
        buttonlogout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

/*

                finish();;
                Intent i=new Intent(getApplicationContext(),Activity_Login.class);
                startActivity(i);
*/


            }
        });

    }



    void alert()
    {


        final Dialog dialog = new Dialog(MenuActivity.this);
        dialog.setContentView(R.layout.custom_dialog);
        dialog.setTitle("Find Path");


        // set the custom dialog components - text, image and button
        final AutoCompleteTextView  editTextSource = (AutoCompleteTextView) dialog.findViewById(R.id.editTextSource);
        final AutoCompleteTextView  editTextDestination = (AutoCompleteTextView ) dialog.findViewById(R.id.editTextDestination);

        editTextSource.setAdapter(new GooglePlacesAutocompleteAdapter(this, R.layout.ist_item));

        editTextSource.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });


        editTextDestination.setAdapter(new GooglePlacesAutocompleteAdapter(this, R.layout.ist_item));

        editTextDestination.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
        Button dialogButton = (Button) dialog.findViewById(R.id.buttonLogin);
        // if button is clicked, close the custom dialog
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                source=  editTextSource.getText().toString();
                destination= editTextDestination.getText().toString();

                if(!source.equals(""))
                {
                    if(!destination.equals(""))
                    {



                        Intent i=new Intent(getApplicationContext(),Show_LiveTracking.class);
                        i.putExtra("source",source);
                        i.putExtra("destination",destination);


                        startActivity(i);



                    }
                }
                dialog.dismiss();
            }
        });

        dialog.show();


    }











    public static ArrayList<String> autocomplete(String input) {
        ArrayList<String> resultList = null;

        HttpURLConnection conn = null;
        StringBuilder jsonResults = new StringBuilder();
        try {
            StringBuilder sb = new StringBuilder(ProjectConfig.PLACES_API_BASE + ProjectConfig.TYPE_AUTOCOMPLETE + ProjectConfig.OUT_JSON);
            sb.append("?key=" + ProjectConfig.API_KEY);
            sb.append("&components=country:in");
            sb.append("&input=" + URLEncoder.encode(input, "utf8"));

            URL url = new URL(sb.toString());

            System.out.println("## URL: "+url);
            conn = (HttpURLConnection) url.openConnection();
            InputStreamReader in = new InputStreamReader(conn.getInputStream());

            // Load the results into a StringBuilder
            int read;
            char[] buff = new char[1024];
            while ((read = in.read(buff)) != -1) {
                jsonResults.append(buff, 0, read);
            }
        } catch (MalformedURLException e) {
            //Log.e(LOG_TAG, "Error processing Places API URL", e);
            return resultList;
        } catch (IOException e) {
           // Log.e(LOG_TAG, "Error connecting to Places API", e);
            return resultList;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        try {

            // Create a JSON object hierarchy from the results
            JSONObject jsonObj = new JSONObject(jsonResults.toString());
            JSONArray predsJsonArray = jsonObj.getJSONArray("predictions");

            // Extract the Place descriptions from the results
            resultList = new ArrayList<String>(predsJsonArray.length());
            for (int i = 0; i < predsJsonArray.length(); i++) {
                System.out.println(predsJsonArray.getJSONObject(i).getString("description"));
                System.out.println("============================================================");
                resultList.add(predsJsonArray.getJSONObject(i).getString("description"));
            }
        } catch (JSONException e) {
           // Log.e(LOG_TAG, "Cannot process JSON results", e);
        }

        return resultList;
    }

    class GooglePlacesAutocompleteAdapter extends ArrayAdapter<String> implements Filterable {
        private ArrayList<String> resultList;

        public GooglePlacesAutocompleteAdapter(Context context, int textViewResourceId) {
            super(context, textViewResourceId);
        }

        @Override
        public int getCount() {
            return resultList.size();
        }

        @Override
        public String getItem(int index) {
            return resultList.get(index);
        }

        @Override
        public Filter getFilter() {
            Filter filter = new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    FilterResults filterResults = new FilterResults();
                    if (constraint != null) {
                        // Retrieve the autocomplete results.
                        resultList = autocomplete(constraint.toString());

                        // Assign the data to the FilterResults
                        filterResults.values = resultList;
                        filterResults.count = resultList.size();

                        System.out.println("## filterResults.values: "+filterResults.values);
                    }
                    return filterResults;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    if (results != null && results.count > 0) {
                        notifyDataSetChanged();
                    } else {
                        notifyDataSetInvalidated();
                    }
                }
            };
            return filter;
        }
    }






}